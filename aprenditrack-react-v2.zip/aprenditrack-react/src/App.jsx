// App.jsx — Shell principal de la aplicación
import { useEffect } from 'react';
import { useStore } from './store';
import Sidebar from './components/Sidebar';
import ToastContainer from './components/Toast';
import { ModalDetalle, ModalNuevo, ModalEditar } from './components/Modals';
import Dashboard from './pages/Dashboard';
import { Aprendices, Grupos, Bitacoras, Seguimientos, Alertas, Raps, Exportar } from './pages/OtherPages';
import './styles/global.css';

const PAGES = {
  dash:         Dashboard,
  aprendices:   Aprendices,
  grupos:       Grupos,
  bitacoras:    Bitacoras,
  seguimientos: Seguimientos,
  alertas:      Alertas,
  raps:         Raps,
  exportar:     Exportar,
};

export default function App() {
  const currentPage = useStore(s => s.currentPage);

  // Cerrar modales con Escape
  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'Escape') {
        const { closeDetail, closeNuevo, closeEditar } = useStore.getState();
        closeDetail(); closeNuevo(); closeEditar();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const Page = PAGES[currentPage] || Dashboard;

  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-content">
        <div className="page-body">
          <Page key={currentPage} />
        </div>
      </div>

      {/* Modales globales */}
      <ModalDetalle />
      <ModalNuevo />
      <ModalEditar />

      {/* Notificaciones */}
      <ToastContainer />
    </div>
  );
}
