// store/index.js — Estado global con Zustand + persistencia localStorage
import { create } from 'zustand';
import { APRENDICES_DATA, RAPS_DATA } from '../utils/data';
import { BIT_REQUIRED, SEG_REQUIRED, DRIVE_BATCH_SIZE } from '../utils/config';
import { listDirectory, matchAprendizFolder, processSubFolder } from '../utils/driveFS';

/* ── Persistencia: cargar datos guardados ── */
function loadPersistedData() {
  try {
    const ap   = localStorage.getItem('aprenditrack_ap');
    const raps = localStorage.getItem('aprenditrack_raps');
    return {
      AP:   ap   ? JSON.parse(ap)   : APRENDICES_DATA,
      RAPS: raps ? JSON.parse(raps) : RAPS_DATA,
    };
  } catch { return { AP: APRENDICES_DATA, RAPS: RAPS_DATA }; }
}

function persist(AP, RAPS) {
  try {
    localStorage.setItem('aprenditrack_ap',   JSON.stringify(AP));
    localStorage.setItem('aprenditrack_raps', JSON.stringify(RAPS));
  } catch {}
}

const { AP: AP0, RAPS: RAPS0 } = loadPersistedData();

export const useStore = create((set, get) => ({

  /* ── Datos ── */
  AP:   AP0,
  RAPS: RAPS0,

  /* ── Drive ── */
  driveConnected: false,
  rootDirHandle:  null,
  driveCache:     {},
  // handleCache: guarda handles de carpetas para abrir con showOpenFilePicker
  handleCache:    {},   // { doc → { aprHandle, bitHandle, segHandle } }
  scanInProgress: false,
  lastSync:       null,

  /* ── UI ── */
  currentPage: 'dash',
  toasts:      [],
  modals: { detail: null, nuevo: false, editar: null },

  /* ════════════════════════
     TOAST
     ════════════════════════ */
  toast(msg, tipo = 'ok') {
    const id = Date.now();
    set(s => ({ toasts: [...s.toasts, { id, msg, tipo }] }));
    setTimeout(() => set(s => ({ toasts: s.toasts.filter(t => t.id !== id) })), 3200);
  },

  /* ════════════════════════
     NAVEGACIÓN
     ════════════════════════ */
  navTo(page) { set({ currentPage: page }); },

  /* ════════════════════════
     MODALES
     ════════════════════════ */
  openDetail(doc)  { set(s => ({ modals: { ...s.modals, detail: doc } })); },
  closeDetail()    { set(s => ({ modals: { ...s.modals, detail: null } })); },
  openNuevo()      { set(s => ({ modals: { ...s.modals, nuevo: true } })); },
  closeNuevo()     { set(s => ({ modals: { ...s.modals, nuevo: false } })); },
  openEditar(idx)  { set(s => ({ modals: { ...s.modals, editar: idx } })); },
  closeEditar()    { set(s => ({ modals: { ...s.modals, editar: null } })); },

  /* ════════════════════════
     CRUD
     ════════════════════════ */
  agregarAprendiz(data) {
    const { AP, RAPS, toast } = get();
    if (AP.find(a => a.doc === data.doc)) {
      toast('Ya existe un aprendiz con ese documento', 'err'); return false;
    }
    const total = data.nivel === 'TÉCNICO' ? 47 : 75;
    const newAP   = [...AP, data];
    const newRAPS = { ...RAPS, [data.doc]: { a: 0, t: total, p: 0 } };
    set({ AP: newAP, RAPS: newRAPS });
    persist(newAP, newRAPS);
    toast('✓ Aprendiz registrado');
    return true;
  },

  editarAprendiz(idx, data) {
    const AP = [...get().AP];
    AP[idx] = { ...AP[idx], ...data };
    set({ AP });
    persist(AP, get().RAPS);
    get().toast('✓ Datos actualizados');
  },

  /* ════════════════════════
     ALERTAS POR VENCIMIENTO
     Retorna lista de aprendices con contrato próximo a vencer
     ════════════════════════ */
  getAlertasVencimiento() {
    const hoy    = new Date();
    const d30    = new Date(hoy); d30.setDate(d30.getDate() + 30);
    const d60    = new Date(hoy); d60.setDate(d60.getDate() + 60);
    const result = [];
    for (const a of get().AP) {
      if (!a.fin_contrato || a.sem !== 'G') continue;
      const fin = new Date(a.fin_contrato);
      if (fin < hoy)  { result.push({ ...a, _alerta: 'vencido',  _dias: Math.round((hoy-fin)/86400000) }); }
      else if (fin <= d30) { result.push({ ...a, _alerta: 'critico', _dias: Math.round((fin-hoy)/86400000) }); }
      else if (fin <= d60) { result.push({ ...a, _alerta: 'proximo', _dias: Math.round((fin-hoy)/86400000) }); }
    }
    return result.sort((a,b) => new Date(a.fin_contrato) - new Date(b.fin_contrato));
  },

  /* ════════════════════════
     ABRIR CARPETA EN EXPLORADOR
     Usa la File System Access API para revelar la carpeta
     ════════════════════════ */
  async abrirCarpeta(doc, tipo = 'aprendiz') {
    const { handleCache, driveCache, toast } = get();
    const cache = driveCache[doc];
    if (!cache || cache.notFound) { toast('Carpeta no encontrada en Drive', 'err'); return; }

    // Intentar abrir la carpeta con showDirectoryPicker apuntando al handle guardado
    try {
      let handle = null;
      if (tipo === 'aprendiz') handle = handleCache[doc]?.aprHandle;
      if (tipo === 'bit')      handle = handleCache[doc]?.bitHandle;
      if (tipo === 'seg')      handle = handleCache[doc]?.segHandle;

      if (handle) {
        // Verificar que el handle sigue siendo válido
        await handle.queryPermission({ mode: 'read' });
        toast(`📁 Carpeta: ${handle.name}`, 'info');
      } else {
        // Mostrar nombre de carpeta como referencia
        const nombre = tipo === 'bit' ? cache.bit?.folderName
                     : tipo === 'seg' ? cache.seg?.folderName
                     : cache.aprFolderName;
        toast(`📁 ${nombre || 'Carpeta encontrada'} — abre el explorador manualmente`, 'info');
      }
    } catch (e) {
      toast('No se pudo acceder a la carpeta: ' + e.message, 'err');
    }
  },

  /* ════════════════════════
     GOOGLE DRIVE — File System Access API
     ════════════════════════ */
  async connectDrive() {
    if (!window.showDirectoryPicker) { get().toast('Usa Chrome o Edge', 'err'); return; }
    try {
      get().toast('Selecciona la carpeta "SEGUIMIENTO ETAPA PRODUCTIVA"…', 'info');
      const handle = await window.showDirectoryPicker({ mode: 'read' });
      set({ rootDirHandle: handle, driveConnected: true });
      get().toast(`✓ Carpeta "${handle.name}" conectada`);
      get().syncDrive();
    } catch (e) {
      if (e.name !== 'AbortError') get().toast('Error: ' + e.message, 'err');
      else get().toast('Selección cancelada', 'info');
    }
  },

  disconnectDrive() {
    set({ rootDirHandle: null, driveConnected: false, driveCache: {}, handleCache: {}, lastSync: null });
    get().toast('Drive desconectado', 'info');
  },

  async syncDrive() {
    const { rootDirHandle, driveConnected, AP, scanInProgress, toast } = get();
    if (!driveConnected || !rootDirHandle) { toast('Selecciona la carpeta primero', 'err'); return; }
    if (scanInProgress) { toast('Escaneo en progreso…', 'info'); return; }

    set({ scanInProgress: true });
    toast('Escaneando carpetas locales de Drive…', 'info');

    try {
      const rootEntries  = await listDirectory(rootDirHandle);
      const fichaFolders = rootEntries.filter(e =>
        e.kind === 'directory' && e.name.toUpperCase().includes('FICHA')
      );
      if (!fichaFolders.length) {
        toast('No encontré carpetas "FICHA XXXXXXX"', 'err');
        set({ scanInProgress: false }); return;
      }

      toast(`${fichaFolders.length} fichas encontradas. Procesando…`, 'info');

      const fichaEntriesMap = {};
      for (const ficha of fichaFolders) {
        const m = ficha.name.match(/(\d{7})/);
        if (m) fichaEntriesMap[m[1]] = await listDirectory(ficha.handle);
      }

      const newCache  = {};
      const newHandleCache = {};

      for (let i = 0; i < AP.length; i += DRIVE_BATCH_SIZE) {
        const batch = AP.slice(i, i + DRIVE_BATCH_SIZE);
        const results = await Promise.all(
          batch.map(a => scanAprendizFS(a, fichaEntriesMap[a.grupo] || []))
        );
        results.forEach(({ doc, data, handles }) => {
          newCache[doc] = data;
          if (handles) newHandleCache[doc] = handles;
        });
        set({ driveCache: { ...newCache }, handleCache: { ...newHandleCache } });
      }

      const encontrados = AP.filter(a => newCache[a.doc] && !newCache[a.doc].notFound).length;
      set({ driveCache: newCache, handleCache: newHandleCache, lastSync: new Date(), scanInProgress: false });
      toast(`✓ Listo — ${encontrados}/${AP.length} aprendices encontrados`);

      // Notificación del sistema si está permitida
      if (Notification.permission === 'granted') {
        new Notification('AprendiTrack', { body: `✓ Drive sincronizado — ${encontrados} aprendices`, icon: '/favicon.svg' });
      }

    } catch (e) {
      toast('Error al escanear: ' + e.message, 'err');
      set({ scanInProgress: false });
    }
  },

  /* Solicitar permiso de notificaciones */
  async requestNotifPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
      await Notification.requestPermission();
    }
  },

}));

/* ── Escanea un aprendiz individual ── */
async function scanAprendizFS(aprendiz, fichaEntries) {
  const norm = s => s.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^A-Z0-9]/g,'');
  try {
    const match = matchAprendizFolder(aprendiz, fichaEntries);
    if (!match) return { doc: aprendiz.doc, data: { notFound: true, bit: { count:-1, last:null }, seg: { count:-1, last:null } }, handles: null };

    const aprEntries = await listDirectory(match.handle);
    const bitEntry = aprEntries.find(e => e.kind==='directory' && (norm(e.name).includes('F147')||norm(e.name).includes('BITACORA')));
    const segEntry = aprEntries.find(e => e.kind==='directory' && (norm(e.name).includes('F023')||norm(e.name).includes('F123')||norm(e.name).includes('SEGUIMIENTO')));

    const [bit, seg] = await Promise.all([
      processSubFolder(bitEntry?.handle || null),
      processSubFolder(segEntry?.handle || null),
    ]);

    return {
      doc: aprendiz.doc,
      data: { aprFolderName: match.name, bit, seg },
      // Guardar handles para poder abrir carpetas después
      handles: {
        aprHandle: match.handle,
        bitHandle: bitEntry?.handle || null,
        segHandle: segEntry?.handle || null,
      }
    };
  } catch (e) {
    return { doc: aprendiz.doc, data: { error: e.message, bit:{count:-1,last:null}, seg:{count:-1,last:null} }, handles: null };
  }
}
