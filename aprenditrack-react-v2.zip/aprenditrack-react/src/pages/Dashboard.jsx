// pages/Dashboard.jsx
import { useState } from 'react';
import { useStore } from '../store';
import { MetricCard, ProgLg, NameCell, StatusBadge, NivelPill, FCount } from '../components/UI';
import { fmtD, bitCount, segCount, barColor } from '../utils/helpers';
import { BIT_REQUIRED, SEG_REQUIRED, PROG_MAP } from '../utils/config';

export default function Dashboard() {
  const { AP, RAPS, driveConnected, driveCache, scanInProgress, syncDrive, navTo, openDetail, openNuevo } = useStore();
  const [q, setQ] = useState('');

  const tot  = AP.length;
  const vig  = AP.filter(a => a.sem === 'G').length;
  const sin  = AP.filter(a => a.sem === 'R').length;
  const bitOk = driveConnected ? AP.filter(a => bitCount(driveCache, a.doc) > 0).length : null;
  const segOk = driveConnected ? AP.filter(a => segCount(driveCache, a.doc) > 0).length : null;
  const pVig  = Math.round(vig / tot * 100);
  const pBit  = driveConnected ? Math.round(bitOk / tot * 100) : 0;
  const pSeg  = driveConnected ? Math.round(segOk / tot * 100) : 0;

  const visible = (q
    ? AP.filter(a => a.nombre.toLowerCase().includes(q.toLowerCase()) || a.doc.includes(q))
    : AP
  ).slice(0, 20);

  const grupos = ['3068389','3147234','3147235','3147251'];

  return (
    <>
      {/* Topbar */}
      <div className="topbar">
        <div className="tb-t">Dashboard <small>— Etapa Productiva</small></div>
        <div className="sbox">
          <SearchIcon />
          <input placeholder="Buscar aprendiz..." value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <button className="btn btn-sena btn-sm" onClick={() => navTo('aprendices')}>Ver todos</button>
        <button
          className="btn-refresh"
          onClick={syncDrive}
          disabled={!driveConnected || scanInProgress}
        >
          <svg className={scanInProgress ? 'spin' : ''} width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M23 4v6h-6"/><path d="M1 20v-6h6"/>
            <path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
          </svg>
          {scanInProgress ? 'Escaneando…' : 'Actualizar Drive'}
        </button>
        <button className="btn btn-sena btn-sm" onClick={openNuevo}>+ Nuevo</button>
      </div>

      <div className="pi">
        {/* KPI Métricas */}
        <div className="mg">
          <MetricCard tipo="s" label="Total aprendices" value={tot} sub="4 fichas · etapa productiva" icon="👥" color="var(--sena)" pct={100} onClick={() => navTo('aprendices')} />
          <MetricCard tipo="g" label="Contratos vigentes" value={vig} sub={`${pVig}% · ${sin} sin contrato`} icon="✅" color="var(--gn)" pct={pVig} onClick={() => navTo('aprendices')} />
          <MetricCard tipo="y" label="F-147 Bitácoras" value={driveConnected ? bitOk : '—'} sub={driveConnected ? `${pBit}% completos · ${tot - bitOk} pendientes` : 'Conecta Drive para ver'} icon="📄" color="var(--yl2)" pct={pBit} onClick={() => navTo('bitacoras')} />
          <MetricCard tipo="b" label="F-023 Seguimientos" value={driveConnected ? segOk : '—'} sub={driveConnected ? `${pSeg}% completos · ${tot - segOk} pendientes` : 'Conecta Drive para ver'} icon="📋" color="var(--bl2)" pct={pSeg} onClick={() => navTo('seguimientos')} />
        </div>

        {/* Panel progreso general */}
        <div className="progress-panel fade-in">
          <h3>
            <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            Resumen de avance general
            <span style={{ fontSize: 10, fontWeight: 400, color: driveConnected ? 'var(--gn)' : 'var(--rd)', marginLeft: 'auto' }}>
              {driveConnected ? '● Drive conectado' : '○ Conecta Drive para ver todo'}
            </span>
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
            <div>
              <ProgLg label="Contratos vigentes" val={vig} total={tot} color="var(--gn)" />
              <ProgLg label="Sin contrato" val={sin} total={tot} color="var(--rd)" />
              <ProgLg label="Terminados" val={AP.filter(a=>a.sem==='Y').length} total={tot} color="var(--yl)" />
            </div>
            <div>
              {driveConnected ? <>
                <ProgLg label="F-147 Bitácoras" val={bitOk} total={tot} color="var(--yl2)" sub={`(${BIT_REQUIRED} arch. c/u)`} />
                <ProgLg label="F-023 Seguimientos" val={segOk} total={tot} color="var(--bl2)" sub={`(${SEG_REQUIRED} arch. c/u)`} />
              </> : (
                <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', flexDirection:'column', gap:10, color:'var(--t3)' }}>
                  <span style={{ fontSize: 28 }}>📁</span>
                  <span style={{ fontSize: 12 }}>Conecta Drive para ver avance de archivos</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="two">
          {/* Tabla principal */}
          <div className="card">
            <div className="ch">
              <div className="ct">Aprendices — <span style={{ color:'var(--sena)' }}>{visible.length}</span></div>
              <button className="btn btn-ghost btn-sm" onClick={() => navTo('aprendices')}>Ver todos →</button>
            </div>
            <div className="tw">
              <table>
                <thead>
                  <tr><th>Nombre</th><th>Nivel</th><th>Grupo</th><th>Contrato</th><th>F-147</th><th>F-023</th><th>RAPs</th></tr>
                </thead>
                <tbody>
                  {visible.map(a => {
                    const r   = RAPS[a.doc] || { p: 0 };
                    const bit = bitCount(driveCache, a.doc);
                    const seg = segCount(driveCache, a.doc);
                    return (
                      <tr key={a.doc} onClick={() => openDetail(a.doc)}>
                        <td><NameCell nombre={a.nombre} sub={a.doc} /></td>
                        <td><NivelPill nivel={a.nivel} /></td>
                        <td style={{ fontSize:12, fontWeight:600 }}>{a.grupo}</td>
                        <td><StatusBadge sem={a.sem} /></td>
                        <td><FCount count={bit} required={BIT_REQUIRED} /></td>
                        <td><FCount count={seg} required={SEG_REQUIRED} /></td>
                        <td>
                          <div className="prog-wrap">
                            <div className="prog"><div className="pf" style={{ width:`${r.p}%`, background: a.sem==='G'?'var(--gn)':'var(--yl)' }} /></div>
                            <span className="prog-pct">{r.p}%</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Alertas urgentes */}
          <div className="card">
            <div className="ch" style={{ background:'var(--rdb)' }}>
              <div className="ct" style={{ color:'var(--rd)' }}>Alertas urgentes</div>
              <span className="mch ch-r">{sin} urgente{sin !== 1 ? 's' : ''}</span>
            </div>
            {AP.filter(a => a.sem === 'R').slice(0, 8).map(a => (
              <div key={a.doc} className="ai" onClick={() => openDetail(a.doc)}>
                <div className="aic aic-r">⚠</div>
                <div style={{ flex:1 }}>
                  <div className="at">{a.nombre}</div>
                  <div className="as2">Sin contrato · {a.grupo}</div>
                </div>
              </div>
            ))}
            {sin === 0 && <div className="empty"><div className="empty-txt">Sin alertas urgentes 🎉</div></div>}
          </div>
        </div>

        {/* Strip fichas por grupo */}
        <div className="card">
          <div className="ch"><div className="ct">Avance por ficha</div></div>
          <div style={{ display:'flex', gap:'1px', background:'var(--slx)' }}>
            {grupos.map(g => {
              const aps  = AP.filter(a => a.grupo === g);
              const vigG = aps.filter(a => a.sem === 'G').length;
              const pV   = aps.length ? Math.round(vigG/aps.length*100) : 0;
              const bitG = driveConnected ? aps.filter(a => bitCount(driveCache, a.doc) > 0).length : null;
              const segG = driveConnected ? aps.filter(a => segCount(driveCache, a.doc) > 0).length : null;
              const pB   = driveConnected && aps.length ? Math.round(bitG/aps.length*100) : 0;
              const pS   = driveConnected && aps.length ? Math.round(segG/aps.length*100) : 0;
              return (
                <div key={g} className="ficha-strip" onClick={() => navTo('grupos')}>
                  <div style={{ display:'flex', alignItems:'baseline', gap:6, marginBottom:2 }}>
                    <div className="ficha-num">{aps.length}</div>
                    <div className="ficha-name" style={{ fontSize:10.5, color:'var(--t2)', fontWeight:700 }}>{PROG_MAP[g]}</div>
                  </div>
                  <div style={{ fontSize:'9.5px', color:'var(--t3)', marginBottom:8 }}>{g}</div>

                  {[
                    { label:'Vigentes',    val:vigG, total:aps.length, pct:pV, color:barColor(pV) },
                    { label:'F-147',       val:bitG ?? '—', total:aps.length, pct:pB, color:'var(--yl2)', hide:!driveConnected },
                    { label:'F-023',       val:segG ?? '—', total:aps.length, pct:pS, color:'var(--bl2)', hide:!driveConnected },
                  ].map(({ label, val, total, pct, color, hide }) => !hide && (
                    <div key={label} style={{ marginBottom:6 }}>
                      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                        <span style={{ fontSize:10, color:'var(--t2)', fontWeight:600 }}>{label}</span>
                        <span style={{ fontSize:10, fontWeight:700, color }}>{val}/{total} · {pct}%</span>
                      </div>
                      <div className="ficha-bar">
                        <div className="ficha-bar-fill" style={{ width:`${pct}%`, background:color }} />
                      </div>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}

function SearchIcon() {
  return <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;
}
