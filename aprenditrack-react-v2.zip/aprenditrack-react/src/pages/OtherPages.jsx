// pages/OtherPages.jsx — Aprendices, Grupos, Bitácoras, Seguimientos, Alertas, RAPs, Exportar
import { useState } from 'react';
import { exportarExcel } from '../utils/exportExcel';
import { useStore } from '../store';
import { NameCell, StatusBadge, NivelPill, FCount, ProgBar, ConnectScreen, ProgLg } from '../components/UI';
import { fmtD, fmtDT, bitCount, segCount, barColor, dlCSV } from '../utils/helpers';
import { BIT_REQUIRED, SEG_REQUIRED, PROG_MAP, INSTRUCTOR } from '../utils/config';

/* ════════════════════════════════════════
   APRENDICES
   ════════════════════════════════════════ */
export function Aprendices() {
  const { AP, RAPS, driveCache, driveConnected, navTo, openDetail, openEditar, openNuevo } = useStore();
  const [q, setQ]       = useState('');
  const [nivel, setNivel] = useState('');
  const [est, setEst]   = useState('');
  const [grp, setGrp]   = useState('');

  const data = AP.filter(a =>
    (!q     || a.nombre.toLowerCase().includes(q.toLowerCase()) || a.doc.includes(q)) &&
    (!nivel || a.nivel === nivel) &&
    (!est   || a.sem   === est) &&
    (!grp   || a.grupo === grp)
  );

  return <>
    <div className="topbar">
      <div className="tb-t">Aprendices</div>
      <div className="sbox"><SearchIco /><input placeholder="Nombre, documento..." value={q} onChange={e=>setQ(e.target.value)} /></div>
      <select className="sf" value={nivel} onChange={e=>setNivel(e.target.value)}>
        <option value="">Todos los niveles</option>
        <option value="TÉCNICO">Técnico</option>
        <option value="TECNÓLOGO">Tecnólogo</option>
      </select>
      <select className="sf" value={est} onChange={e=>setEst(e.target.value)}>
        <option value="">Todos los estados</option>
        <option value="G">Vigente</option><option value="Y">Terminado</option><option value="R">Sin contrato</option>
      </select>
      <select className="sf" value={grp} onChange={e=>setGrp(e.target.value)}>
        <option value="">Todos los grupos</option>
        {['3068389','3147234','3147235','3147251'].map(g => <option key={g} value={g}>{g}</option>)}
      </select>
      <button className="btn btn-sena btn-sm" onClick={openNuevo}>+ Nuevo</button>
    </div>
    <div style={{ padding:0 }}>
      <div className="card" style={{ borderRadius:0, border:'none', margin:0 }}>
        <div className="tw">
          <table>
            <thead><tr><th>#</th><th>Nombre</th><th>Documento</th><th>Nivel</th><th>Grupo</th><th>Inicio EP</th><th>Fin contrato</th><th>F-147</th><th>F-023</th><th>RAPs</th><th>Estado</th><th>Acc.</th></tr></thead>
            <tbody>
              {data.map((a,i) => {
                const r   = RAPS[a.doc] || { a:0, t:1, p:0 };
                const bit = bitCount(driveCache, a.doc);
                const seg = segCount(driveCache, a.doc);
                return (
                  <tr key={a.doc} onClick={()=>openDetail(a.doc)}>
                    <td style={{color:'var(--t3)',fontSize:11}}>{i+1}</td>
                    <td><NameCell nombre={a.nombre} sub={a.programa} /></td>
                    <td style={{fontWeight:600}}>{a.doc}</td>
                    <td><NivelPill nivel={a.nivel} /></td>
                    <td style={{fontSize:12,fontWeight:600,color:'var(--sena2)'}}>{a.grupo}</td>
                    <td style={{fontSize:12}}>{fmtD(a.inicio_ep)}</td>
                    <td style={{fontSize:12}}>{a.fin_contrato ? fmtD(a.fin_contrato) : <span style={{color:'var(--rd)',fontWeight:600}}>—</span>}</td>
                    <td><FCount count={bit} required={BIT_REQUIRED} /></td>
                    <td><FCount count={seg} required={SEG_REQUIRED} /></td>
                    <td><ProgBar pct={r.p} sem={a.sem} /></td>
                    <td><StatusBadge sem={a.sem} /></td>
                    <td onClick={e=>e.stopPropagation()}>
                      <div style={{display:'flex',gap:5}}>
                        <button className="btn btn-ghost btn-sm" onClick={()=>openDetail(a.doc)}>Ver</button>
                        <button className="btn btn-ghost btn-sm" onClick={()=>openEditar(AP.indexOf(a))}>✏</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {data.length === 0 && <div className="empty"><div className="empty-txt">Sin resultados</div></div>}
      </div>
    </div>
  </>;
}

/* ════════════════════════════════════════
   GRUPOS
   ════════════════════════════════════════ */
export function Grupos() {
  const { AP, driveCache, driveConnected } = useStore();
  const grupos = [
    { id:'3068389', nombre:'Programación de Software' },
    { id:'3147234', nombre:'Análisis y Desarrollo — A' },
    { id:'3147235', nombre:'Análisis y Desarrollo — B' },
    { id:'3147251', nombre:'Análisis y Desarrollo — C' },
  ];
  return <>
    <div className="topbar"><div className="tb-t">Grupos y Fichas</div></div>
    <div className="pi">
      <div className="gg">
        {grupos.map(({ id, nombre }) => {
          const aps  = AP.filter(a => a.grupo === id);
          const vig  = aps.filter(a => a.sem === 'G').length;
          const sin  = aps.filter(a => a.sem === 'R').length;
          const ter  = aps.filter(a => a.sem === 'Y').length;
          const pVig = aps.length ? Math.round(vig/aps.length*100) : 0;
          const bitOk = driveConnected ? aps.filter(a=>bitCount(driveCache,a.doc)>0).length : null;
          const segOk = driveConnected ? aps.filter(a=>segCount(driveCache,a.doc)>0).length : null;
          return (
            <div key={id} className="gc">
              <div className="gct">Ficha {id}</div>
              <div className="gcs">{nombre} · {aps[0]?.nivel||'—'}</div>
              <div className="gcst">
                {[{v:aps.length,l:'Total',c:'var(--sena2)'},{v:vig,l:'Vigentes',c:'var(--gn)'},{v:ter,l:'Terminados',c:'var(--yl)'},{v:sin,l:'Sin contrato',c:'var(--rd)'}].map(({v,l,c})=>(
                  <div key={l}><div className="gcsv" style={{color:c}}>{v}</div><div className="gcsl">{l}</div></div>
                ))}
              </div>
              <ProgLg label="Contratos vigentes" val={vig} total={aps.length} color="var(--gn)" />
              {driveConnected && <>
                <ProgLg label="F-147 Bitácoras" val={bitOk} total={aps.length} color="var(--yl2)" />
                <ProgLg label="F-023 Seguimientos" val={segOk} total={aps.length} color="var(--bl2)" />
              </>}
              {!driveConnected && <div style={{fontSize:11,color:'var(--t3)',marginTop:4}}>Conecta Drive para ver archivos</div>}
            </div>
          );
        })}
      </div>
    </div>
  </>;
}

/* ════════════════════════════════════════
   BITÁCORAS
   ════════════════════════════════════════ */
export function Bitacoras() {
  const { AP, driveCache, handleCache, driveConnected, connectDrive, syncDrive, scanInProgress, abrirCarpeta } = useStore();
  const [q, setQ]   = useState('');
  const [grp, setGrp] = useState('');

  const data = AP.filter(a =>
    (!q   || a.nombre.toLowerCase().includes(q.toLowerCase()) || a.doc.includes(q)) &&
    (!grp || a.grupo === grp)
  );
  const ok   = driveConnected ? data.filter(a=>bitCount(driveCache,a.doc)>0).length : null;
  const miss = driveConnected ? data.filter(a=>bitCount(driveCache,a.doc)===0).length : null;
  const nf   = driveConnected ? data.filter(a=>bitCount(driveCache,a.doc)===-1).length : null;

  return <>
    <div className="topbar">
      <div className="tb-t">F-147 BITÁCORAS <small>— archivos por aprendiz</small></div>
      <div className="sbox"><SearchIco /><input placeholder="Buscar aprendiz..." value={q} onChange={e=>setQ(e.target.value)} /></div>
      <select className="sf" value={grp} onChange={e=>setGrp(e.target.value)}>
        <option value="">Todos</option>
        {['3068389','3147234','3147235','3147251'].map(g=><option key={g} value={g}>{g}</option>)}
      </select>
      <button className="btn btn-sena btn-sm" onClick={syncDrive} disabled={!driveConnected||scanInProgress}>
        {scanInProgress ? 'Escaneando…' : 'Escanear Drive'}
      </button>
    </div>
    <div className="pi">
      {!driveConnected ? <ConnectScreen onConnect={connectDrive} /> : <>
        <div className="mg" style={{gridTemplateColumns:'repeat(4,1fr)'}}>
          {[{t:'g',l:'Con archivos',v:ok},{t:'r',l:'Sin archivos',v:miss},{t:'b',l:'No encontrados',v:nf},{t:'s',l:'Total aprendices',v:data.length}].map(({t,l,v})=>(
            <div key={l} className={`mc mc-${t}`}><div className="ml">{l}</div><div className="mv">{v??'—'}</div></div>
          ))}
        </div>
        <div className="card">
          <div className="ch"><div className="ct">F-147 BITÁCORAS — Archivos en Drive</div></div>
          <div className="tw">
            <table>
              <thead><tr><th>#</th><th>Aprendiz</th><th>Grupo</th><th>Carpeta</th><th>Archivos</th><th>Último archivo</th><th>Estado</th><th>Abrir</th></tr></thead>
              <tbody>
                {data.map((a,i) => {
                  const bd    = driveCache[a.doc]?.bit;
                  const count = bd?.count ?? -1;
                  const cache = driveCache[a.doc];
                  return (
                    <tr key={a.doc}>
                      <td style={{color:'var(--t3)',fontSize:11}}>{i+1}</td>
                      <td><NameCell nombre={a.nombre} sub={a.doc} /></td>
                      <td style={{fontSize:12,fontWeight:600,color:'var(--sena2)'}}>{a.grupo}</td>
                      <td style={{fontSize:11,color:'var(--t2)'}}>{cache?.aprFolderName||(cache?.notFound?'⚠ No encontrado':'—')}</td>
                      <td><FCount count={count} required={BIT_REQUIRED} /></td>
                      <td style={{fontSize:11.5}}>{bd?.last ? fmtDT(bd.last) : '—'}</td>
                      <td>
                        {count===-1 ? <span className="fcount fc-na">No encontrado</span>
                          : count>0  ? <span className="fcount fc-ok">Con archivos ✓</span>
                          : <span className="fcount fc-miss">Sin archivos</span>}
                      </td>
                      <td>
                        {driveCache[a.doc] && !driveCache[a.doc].notFound ? (
                          <div style={{display:'flex',flexDirection:'column',gap:4}}>
                            <button className="btn btn-ghost btn-sm" onClick={()=>abrirCarpeta(a.doc,'aprendiz')} style={{fontSize:10.5}}>
                              📁 Carpeta aprendiz
                            </button>
                            {driveCache[a.doc]?.bit?.folderName && (
                              <button className="btn btn-ghost btn-sm" onClick={()=>abrirCarpeta(a.doc,'bit')} style={{fontSize:10.5}}>
                                📄 F-147 Bitácoras
                              </button>
                            )}
                          </div>
                        ) : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </>}
    </div>
  </>;
}

/* ════════════════════════════════════════
   SEGUIMIENTOS
   ════════════════════════════════════════ */
export function Seguimientos() {
  const { AP, driveCache, driveConnected, connectDrive, syncDrive, scanInProgress, abrirCarpeta } = useStore();
  const [q, setQ]   = useState('');
  const [grp, setGrp] = useState('');

  const data = AP.filter(a =>
    (!q   || a.nombre.toLowerCase().includes(q.toLowerCase()) || a.doc.includes(q)) &&
    (!grp || a.grupo === grp)
  );

  return <>
    <div className="topbar">
      <div className="tb-t">F-023 SEGUIMIENTOS <small>— archivos por aprendiz</small></div>
      <div className="sbox"><SearchIco /><input placeholder="Buscar aprendiz..." value={q} onChange={e=>setQ(e.target.value)} /></div>
      <select className="sf" value={grp} onChange={e=>setGrp(e.target.value)}>
        <option value="">Todos</option>
        {['3068389','3147234','3147235','3147251'].map(g=><option key={g} value={g}>{g}</option>)}
      </select>
      <button className="btn btn-sena btn-sm" onClick={syncDrive} disabled={!driveConnected||scanInProgress}>
        {scanInProgress ? 'Escaneando…' : 'Escanear Drive'}
      </button>
    </div>
    <div className="pi">
      {!driveConnected ? <ConnectScreen onConnect={connectDrive} /> : <>
        <div className="card">
          <div className="ch"><div className="ct">F-023 SEGUIMIENTOS — Archivos en Drive</div></div>
          <div className="tw">
            <table>
              <thead><tr><th>#</th><th>Aprendiz</th><th>Grupo</th><th>Carpeta</th><th>Archivos</th><th>Último archivo</th><th>Estado</th><th>Abrir</th></tr></thead>
              <tbody>
                {data.map((a,i) => {
                  const sd    = driveCache[a.doc]?.seg;
                  const count = sd?.count ?? -1;
                  const cache = driveCache[a.doc];
                  return (
                    <tr key={a.doc}>
                      <td style={{color:'var(--t3)',fontSize:11}}>{i+1}</td>
                      <td><NameCell nombre={a.nombre} sub={a.doc} /></td>
                      <td style={{fontSize:12,fontWeight:600,color:'var(--sena2)'}}>{a.grupo}</td>
                      <td style={{fontSize:11,color:'var(--t2)'}}>{cache?.aprFolderName||(cache?.notFound?'⚠ No encontrado':'—')}</td>
                      <td><FCount count={count} required={SEG_REQUIRED} /></td>
                      <td style={{fontSize:11.5}}>{sd?.last ? fmtDT(sd.last) : '—'}</td>
                      <td>
                        {count===-1 ? <span className="fcount fc-na">No encontrado</span>
                          : count>0  ? <span className="fcount fc-ok">Con archivos ✓</span>
                          : <span className="fcount fc-miss">Sin archivos</span>}
                      </td>
                      <td>
                        {driveCache[a.doc] && !driveCache[a.doc].notFound ? (
                          <div style={{display:'flex',flexDirection:'column',gap:4}}>
                            <button className="btn btn-ghost btn-sm" onClick={()=>abrirCarpeta(a.doc,'aprendiz')} style={{fontSize:10.5}}>
                              📁 Carpeta aprendiz
                            </button>
                            {driveCache[a.doc]?.seg?.folderName && (
                              <button className="btn btn-ghost btn-sm" onClick={()=>abrirCarpeta(a.doc,'seg')} style={{fontSize:10.5}}>
                                ✅ F-023 Seguimientos
                              </button>
                            )}
                          </div>
                        ) : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </>}
    </div>
  </>;
}

/* ════════════════════════════════════════
   ALERTAS — incluye vencimientos de contrato
   ════════════════════════════════════════ */
export function Alertas() {
  const { AP, RAPS, driveCache, driveConnected, openDetail, getAlertasVencimiento } = useStore();
  const [tab, setTab] = useState('all');

  const sinCont  = AP.filter(a => a.sem === 'R');
  const bitPend  = driveConnected ? AP.filter(a => { const c=bitCount(driveCache,a.doc); return c>=0&&c<BIT_REQUIRED; }) : [];
  const segPend  = driveConnected ? AP.filter(a => { const c=segCount(driveCache,a.doc); return c>=0&&c<SEG_REQUIRED; }) : [];
  const vencim   = getAlertasVencimiento();
  const vencCrit = vencim.filter(a => a._alerta === 'vencido' || a._alerta === 'critico');

  const Item = ({a, icon, cls, desc, badge}) => (
    <div className="ai" onClick={()=>openDetail(a.doc)}>
      <div className={`aic ${cls}`}>{icon}</div>
      <div style={{flex:1}}>
        <div className="at">{a.nombre}</div>
        <div className="as2">{desc}</div>
      </div>
      {badge && <span style={{fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:10,background:badge.bg,color:badge.c,whiteSpace:'nowrap'}}>{badge.label}</span>}
      <div className="atm">{a.grupo}</div>
    </div>
  );
  const Empty = ({msg}) => <div className="empty"><div className="empty-txt">{msg}</div></div>;

  const vencBadge = (a) => {
    if (a._alerta==='vencido')  return {bg:'var(--rdb)',c:'var(--rd)',  label:`Venció hace ${a._dias}d`};
    if (a._alerta==='critico')  return {bg:'var(--rdb)',c:'var(--rd)',  label:`${a._dias} días`};
    return                              {bg:'var(--ylb)',c:'var(--yl)', label:`${a._dias} días`};
  };

  const tabs = [
    {id:'all',   label:`Todas (${sinCont.length+vencCrit.length+bitPend.length+segPend.length})`},
    {id:'sin',   label:`Sin contrato (${sinCont.length})`},
    {id:'venc',  label:`Vencimientos (${vencim.length})`},
    {id:'bit',   label:`F-147 (${bitPend.length})`},
    {id:'seg',   label:`F-023 (${segPend.length})`},
  ];

  return <>
    <div className="topbar"><div className="tb-t">Centro de alertas</div></div>
    <div className="pi">
      <div className="mg" style={{gridTemplateColumns:'repeat(4,1fr)'}}>
        <div className="mc mc-r"><div className="ml">Sin contrato</div><div className="mv" style={{color:'var(--rd)'}}>{sinCont.length}</div></div>
        <div className="mc mc-r"><div className="ml">Contratos vencidos/críticos</div><div className="mv" style={{color:'var(--rd)'}}>{vencCrit.length}</div><div className="ms" style={{fontSize:10}}>{vencim.length} con alerta total</div></div>
        <div className="mc mc-y"><div className="ml">F-147 pendientes</div><div className="mv" style={{color:'var(--yl)'}}>{driveConnected?bitPend.length:'—'}</div></div>
        <div className="mc mc-b"><div className="ml">F-023 pendientes</div><div className="mv" style={{color:'var(--bl)'}}>{driveConnected?segPend.length:'—'}</div></div>
      </div>
      <div className="card">
        <div className="tabs">
          {tabs.map(t=><button key={t.id} className={`tab-btn${tab===t.id?' active':''}`} onClick={()=>setTab(t.id)}>{t.label}</button>)}
        </div>
        {tab==='all'&&<>
          {sinCont.map(a=><Item key={a.doc} a={a} icon="⚠" cls="aic-r" desc="Sin contrato de aprendizaje" />)}
          {vencCrit.map(a=><Item key={a.doc} a={a} icon="📅" cls="aic-r" desc={`Fin contrato: ${fmtD(a.fin_contrato)}`} badge={vencBadge(a)} />)}
          {bitPend.map(a=><Item key={a.doc} a={a} icon="📄" cls="aic-y" desc={`F-147: ${bitCount(driveCache,a.doc)} archivos encontrados`} />)}
          {segPend.map(a=><Item key={a.doc} a={a} icon="✅" cls="aic-b" desc={`F-023: ${segCount(driveCache,a.doc)} archivos encontrados`} />)}
          {sinCont.length+vencCrit.length+bitPend.length+segPend.length===0&&<Empty msg="Sin alertas activas 🎉" />}
        </>}
        {tab==='sin' &&(sinCont.length>0 ?sinCont.map(a=><Item key={a.doc} a={a} icon="⚠" cls="aic-r" desc={`Sin contrato · Inicio EP: ${fmtD(a.inicio_ep)}`} />):<Empty msg="Todos tienen contrato ✓" />)}
        {tab==='venc'&&(vencim.length>0  ?vencim.map(a=><Item key={a.doc} a={a} icon="📅" cls={a._alerta==='proximo'?'aic-y':'aic-r'} desc={`Fin: ${fmtD(a.fin_contrato)} · ${a.programa}`} badge={vencBadge(a)} />):<Empty msg="Sin vencimientos próximos ✓" />)}
        {tab==='bit' &&(bitPend.length>0 ?bitPend.map(a=><Item key={a.doc} a={a} icon="📄" cls="aic-y" desc={`${bitCount(driveCache,a.doc)} archivos encontrados`} />):<Empty msg={driveConnected?'Todos completos ✓':'Conecta Drive para ver'} />)}
        {tab==='seg' &&(segPend.length>0 ?segPend.map(a=><Item key={a.doc} a={a} icon="✅" cls="aic-b" desc={`${segCount(driveCache,a.doc)} archivos encontrados`} />):<Empty msg={driveConnected?'Todos completos ✓':'Conecta Drive para ver'} />)}
      </div>
    </div>
  </>;
}

/* ════════════════════════════════════════
   RAPs
   ════════════════════════════════════════ */
export function Raps() {
  const { AP, RAPS } = useStore();
  const [q, setQ]   = useState('');
  const [ord, setOrd] = useState('asc');

  const data = AP
    .filter(a => !q || a.nombre.toLowerCase().includes(q.toLowerCase()) || a.doc.includes(q))
    .sort((a,b) => {
      const pa = RAPS[a.doc]?.p||0, pb = RAPS[b.doc]?.p||0;
      return ord==='asc' ? pa-pb : pb-pa;
    });

  const promedio = Math.round(data.reduce((s,a)=>s+(RAPS[a.doc]?.p||0),0)/(data.length||1));
  const over90   = data.filter(a=>(RAPS[a.doc]?.p||0)>=90).length;
  const under50  = data.filter(a=>(RAPS[a.doc]?.p||0)<50).length;

  return <>
    <div className="topbar">
      <div className="tb-t">RAPs y avance académico</div>
      <div className="sbox"><SearchIco /><input placeholder="Buscar..." value={q} onChange={e=>setQ(e.target.value)} /></div>
      <select className="sf" value={ord} onChange={e=>setOrd(e.target.value)}>
        <option value="asc">Menor avance primero</option>
        <option value="desc">Mayor avance primero</option>
      </select>
    </div>
    <div className="pi">
      <div className="mg" style={{gridTemplateColumns:'repeat(3,1fr)'}}>
        <div className="mc mc-s"><div className="ml">Promedio RAPs</div><div className="mv">{promedio}<span style={{fontSize:16}}>%</span></div></div>
        <div className="mc mc-g"><div className="ml">≥ 90% avance</div><div className="mv" style={{color:'var(--gn)'}}>{over90}</div></div>
        <div className="mc mc-r"><div className="ml">&lt; 50% avance</div><div className="mv" style={{color:'var(--rd)'}}>{under50}</div></div>
      </div>
      <div className="card">
        <div className="ch"><div className="ct">Avance RAPs por aprendiz</div></div>
        <div className="tw">
          <table>
            <thead><tr><th>#</th><th>Aprendiz</th><th>Nivel</th><th>Grupo</th><th>Aprobados</th><th>Total</th><th>% Avance</th><th>Estado EP</th></tr></thead>
            <tbody>
              {data.map((a,i)=>{
                const r=RAPS[a.doc]||{a:0,t:1,p:0};
                return (
                  <tr key={a.doc}>
                    <td style={{color:'var(--t3)',fontSize:11}}>{i+1}</td>
                    <td><NameCell nombre={a.nombre} /></td>
                    <td><NivelPill nivel={a.nivel} /></td>
                    <td style={{fontSize:12,fontWeight:600,color:'var(--sena2)'}}>{a.grupo}</td>
                    <td style={{fontWeight:700,color:'var(--gn)'}}>{r.a}</td>
                    <td style={{fontWeight:700}}>{r.t}</td>
                    <td><ProgBar pct={r.p} sem={a.sem} /></td>
                    <td><StatusBadge sem={a.sem} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </>;
}

/* ════════════════════════════════════════
   EXPORTAR — Excel real con 4 hojas
   ════════════════════════════════════════ */
export function Exportar() {
  const { AP, RAPS, driveCache, driveConnected, getAlertasVencimiento } = useStore();

  const exportar = (tipo) => {
    if (tipo === 'excel') {
      exportarExcel(AP, RAPS, driveCache, getAlertasVencimiento());
      return;
    }
    // CSV básico para casos simples
    let data = AP, fname = 'aprendices.csv';
    if (tipo==='vigentes')     { data=AP.filter(a=>a.sem==='G'); fname='vigentes.csv'; }
    if (tipo==='sin_contrato') { data=AP.filter(a=>a.sem==='R'); fname='sin_contrato.csv'; }
    const hdr = 'Nombre,Documento,Nivel,Grupo,Programa,Correo,Inicio EP,Fin Contrato,Estado,RAPs %';
    const rows = data.map(a=>[a.nombre,a.doc,a.nivel,a.grupo,a.programa,a.correo,a.inicio_ep||'',a.fin_contrato||'',a.sem==='G'?'Vigente':a.sem==='Y'?'Terminado':'Sin contrato',(RAPS[a.doc]?.p||0)+'%'].join(','));
    dlCSV([hdr,...rows].join('\n'),fname);
  };

  const tot=AP.length, vig=AP.filter(a=>a.sem==='G').length, sin=AP.filter(a=>a.sem==='R').length;
  const f=new Date().toLocaleDateString('es-CO',{year:'numeric',month:'long',day:'numeric'});
  const reporte=[
    `REPORTE APRENDITRACK — ${f}`,
    `Instructor: ${INSTRUCTOR.nombre} | SENA`,
    `Drive: ${driveConnected?'Conectado':'Desconectado'}`,
    '─'.repeat(52),
    `Total aprendices: ${tot}`,
    `Contratos vigentes: ${vig} (${Math.round(vig/tot*100)}%)`,
    `Sin contrato: ${sin}`,
  ].join('\n');

  return <>
    <div className="topbar"><div className="tb-t">Exportar datos</div></div>
    <div className="pi">
      <div className="two">
        <div>
          <div className="card">
            <div className="ch"><div className="ct">Descargar CSV</div></div>
            <div style={{padding:16,display:'flex',flexDirection:'column',gap:9}}>
              <button className="btn btn-sena" onClick={()=>exportar('excel')}>
                📊 Exportar Excel completo (.xlsx)
              </button>
              <div style={{fontSize:11,color:'var(--t3)',padding:'2px 4px'}}>
                Incluye 4 hojas: Resumen · Aprendices · Drive · Alertas
              </div>
              <hr style={{border:'none',borderTop:'1px solid var(--bg3)',margin:'3px 0'}}/>
              <button className="btn btn-out"  onClick={()=>exportar('vigentes')}>⬇ CSV — Contratos vigentes</button>
              <button className="btn btn-out"  onClick={()=>exportar('sin_contrato')}>⬇ CSV — Sin contrato</button>
              <button className="btn btn-out"  onClick={()=>exportar('todos')}>⬇ CSV — Todos los aprendices</button>
              <hr style={{border:'none',borderTop:'1px solid var(--bg3)',margin:'3px 0'}}/>
              <button className="btn btn-drive" onClick={()=>navigator.clipboard.writeText(reporte)}>📋 Copiar reporte de texto</button>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="ch"><div className="ct">Vista previa</div></div>
          <div style={{padding:14}}>
            <pre style={{fontSize:11,color:'var(--t2)',lineHeight:1.7,whiteSpace:'pre-wrap',fontFamily:'monospace',background:'var(--bg3)',padding:13,borderRadius:8,overflow:'auto',maxHeight:400,border:'1px solid var(--bd)'}}>{reporte}</pre>
          </div>
        </div>
      </div>
    </div>
  </>;
}

function SearchIco() {
  return <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;
}
