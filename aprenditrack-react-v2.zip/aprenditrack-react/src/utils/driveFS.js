// utils/driveFS.js — File System Access API helpers

/** Lista todas las entradas de un DirectoryHandle */
export async function listDirectory(dirHandle) {
  const entries = [];
  try {
    for await (const [name, handle] of dirHandle.entries()) {
      entries.push({ name, kind: handle.kind, handle });
    }
  } catch (e) {
    console.warn('Error listando', dirHandle.name, e);
  }
  return entries;
}

/** Normaliza string: quita tildes, guiones, espacios → solo alfanumérico */
const norm = s => s.toUpperCase()
  .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  .replace(/[^A-Z0-9]/g, '');

/** Fuzzy match: aprendiz vs entradas de carpeta. Requiere ≥2 palabras coincidentes */
export function matchAprendizFolder(aprendiz, entries) {
  const words = aprendiz.nombre.toUpperCase().split(' ').filter(w => w.length > 2);
  let best = null, bestScore = 0;
  for (const entry of entries) {
    if (entry.kind !== 'directory') continue;
    const fn = entry.name.toUpperCase();
    let score = 0;
    for (const word of words) { if (fn.includes(word)) score++; }
    if (score > bestScore) { bestScore = score; best = entry; }
  }
  return bestScore >= 2 ? best : null;
}

/**
 * Cuenta TODOS los archivos de una subcarpeta (sin filtrar extensión).
 * Entra 1 nivel recursivo si hay subcarpetas internas.
 */
export async function processSubFolder(subHandle) {
  if (!subHandle) return { count: 0, last: null, folderName: null };
  try {
    const entries  = await listDirectory(subHandle);
    const allFiles = [];

    for (const entry of entries) {
      if (entry.kind === 'file') {
        if (!entry.name.startsWith('.') && entry.name.toLowerCase() !== 'thumbs.db') {
          allFiles.push(entry);
        }
      } else if (entry.kind === 'directory') {
        try {
          const sub = await listDirectory(entry.handle);
          sub.forEach(e => {
            if (e.kind === 'file' && !e.name.startsWith('.')) allFiles.push(e);
          });
        } catch (_) {}
      }
    }

    let lastDate = null;
    for (const f of allFiles) {
      try {
        const file = await f.handle.getFile();
        if (!lastDate || file.lastModified > lastDate) lastDate = file.lastModified;
      } catch (_) {}
    }

    return {
      count:      allFiles.length,
      last:       lastDate ? new Date(lastDate).toISOString() : null,
      folderName: subHandle.name,
    };
  } catch (e) {
    return { count: 0, last: null, folderName: subHandle?.name };
  }
}
