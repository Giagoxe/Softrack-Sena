// utils/helpers.js — Funciones de utilidad puras
import { PALETTE, BIT_REQUIRED, SEG_REQUIRED } from './config';

export const initials = n => {
  const p = n.trim().split(' ');
  return (p[0][0] + (p[p.length - 1]?.[0] || '')).toUpperCase();
};

export const colFor = n => {
  let h = 0;
  for (const c of n) h = (h * 31 + c.charCodeAt(0)) % PALETTE.length;
  return PALETTE[h];
};

export const fmtD  = d => d ? d.substring(0, 10) : '—';
export const fmtDT = d => d ? new Date(d).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
export const hoy   = () => new Date().toISOString().substring(0, 10);

export const barColor = pct =>
  pct >= 80 ? 'var(--gn)' : pct >= 40 ? 'var(--yl2)' : 'var(--rd2)';

/** Estado contrato: G=Vigente, Y=Terminado, R=Sin contrato */
export const semLabel = s => ({ G: 'Vigente', Y: 'Terminado', R: 'Sin contrato' }[s] || 'Sin contrato');
export const semClass = s => ({ G: 'st-G', Y: 'st-Y', R: 'st-R' }[s] || 'st-R');

/** Datos Drive de un aprendiz desde el cache */
export const getBitData  = (cache, doc) => cache[doc]?.bit || null;
export const getSegData  = (cache, doc) => cache[doc]?.seg || null;
export const bitCount    = (cache, doc) => getBitData(cache, doc)?.count ?? -1;
export const segCount    = (cache, doc) => getSegData(cache, doc)?.count ?? -1;
export const bitComplete = (cache, doc) => bitCount(cache, doc) >= BIT_REQUIRED;
export const segComplete = (cache, doc) => segCount(cache, doc) >= SEG_REQUIRED;

/** Descarga un CSV en el navegador */
export function dlCSV(content, fname) {
  const a   = document.createElement('a');
  a.href    = URL.createObjectURL(new Blob(['\uFEFF' + content], { type: 'text/csv;charset=utf-8' }));
  a.download = fname;
  a.click();
  URL.revokeObjectURL(a.href);
}
