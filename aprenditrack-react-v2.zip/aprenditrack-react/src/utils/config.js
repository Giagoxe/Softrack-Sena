// utils/config.js — Configuración global
export const CLIENT_ID        = '48622540259-ia3pubg6tu4no01cc189v9bssn1ldu33.apps.googleusercontent.com';
export const DRIVE_ROOT       = '19xAcoGRg0g3aQPGP8HcK_cW_jJAFnMB0';
export const BIT_REQUIRED     = 12;
export const SEG_REQUIRED     = 4;
export const DRIVE_BATCH_SIZE = 5;
export const INSTRUCTOR       = { nombre: 'Andrei Gómez', iniciales: 'AG', rol: 'Instructor SENA' };
export const PROG_MAP = {
  '3068389': 'Programación de Software',
  '3147234': 'Análisis y Desarrollo — A',
  '3147235': 'Análisis y Desarrollo — B',
  '3147251': 'Análisis y Desarrollo — C',
};
export const PALETTE = ['#007a30','#1565c0','#c43400','#6c3483','#117a65','#784212','#0d47a1','#7d6608'];
