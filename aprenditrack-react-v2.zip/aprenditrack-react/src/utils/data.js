// utils/data.js — Datos reales de los 95 aprendices
// Edita directamente aquí para agregar/modificar grupos

export const APRENDICES_DATA = [
  /* ── GRUPO 3068389 — PROGRAMACIÓN DE SOFTWARE (Técnico) ── */
  {"nombre":"DANIEL JESUS LOZANO GARCIA","doc":"1043967541","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"danielj.lozanog@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2025-07-14","sem":"Y"},
  {"nombre":"ZOLANYI KARINA MUÑOZ CHITIVA","doc":"1074415481","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"zolkmunoz1572@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"BRAYAN DAVID RAMIREZ RODRIGUEZ","doc":"1140914672","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"brayandavidramirezr2006@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"JUAN NICOLAS HERRERA BOBADILLA","doc":"1141515184","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"juanicolasherrera@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"BRAYAN ESTIVEN DIAZ GARZON","doc":"1193230246","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"brayandiaz11993230@outlook.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"SANTIAGO EMILIO LÓPEZ PÁEZ","doc":"1012370457","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"santiagolopez2979@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"DYLAN SANCHEZ VILLAMIL","doc":"1019991485","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"dylansanchezvillamil.est.panama@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"MARIA FERNANDA CARRILLO TORRES","doc":"1022355461","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"xamaxama1401@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"ANGELO DAVID RUEDA BARRERA","doc":"1023374300","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"angelodaviruedabarrera8a@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"NICOLAS CASTELLANOS ORTEGÓN","doc":"1023378880","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"nicolascastellanos0220@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-05-09","sem":"G"},
  {"nombre":"EDWAR ESTEBAN RAIGOSO GARZON","doc":"1028663706","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"edwarraigoso12@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"LAURA SOFIA VILLAMIZAR OVIEDO","doc":"1098072982","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"lausv2024@gmail.com","inicio_ep":"2025-07-14","fin_contrato":"2026-01-14","sem":"G"},
  {"nombre":"JUAN PABLO RIOS FRANCO","doc":"1140915524","programa":"PROGRAMACION DE SOFTWARE","nivel":"TÉCNICO","grupo":"3068389","correo":"juanpablo160906@gmail.com","inicio_ep":"2025-07-14","fin_contrato":null,"sem":"R"},

  /* ── GRUPO 3147234 — ADSO (Tecnólogo) ── */
  {"nombre":"JOSE RODRIGO OTALORA BAUTISTA","doc":"1011093715","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"maizpeto499@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"CAMILO ANDRES PINZON MELENDRES","doc":"1013110718","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"camiloandrespinzonmelendrez@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JUAN CAMILO SILVA GRANADOS","doc":"1019030642","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"camilosilvaj007@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DANNA VALENTINA BENAVIDES CHINCHILLA","doc":"1019045156","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"valentinabenavides1803@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JOSTHIN SEBASTIAN PAZ NIETO","doc":"1021314075","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"josthinpaz2@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DOUGLAS EDUARDO RAMIREZ ROMERO","doc":"1028400763","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"douglaseduardoramirez77@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JAMES DAVID ARIAS RENDON","doc":"1028941954","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"rendondavid328@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"VALENTINA SIERRA SANCHEZ","doc":"1029280463","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"sanchez2007.valentina@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"SOFIA SEGURA GUACARE","doc":"1031651340","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"ssegur403@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JOHAN SEBASTIAN PRADO VARGAS","doc":"1031810329","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"sebastianprado729@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JUAN ESTEBAN VARELA ACUÑA","doc":"1031812418","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"juanvarela1730@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JULIANA GARCIA PEREZ","doc":"1052964591","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"julianagarciaperez6@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JUAN SEBASTIAN QUINTERO SILVA","doc":"1121202003","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"juanquntero049@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"CESAR EDUARDO JIMENEZ DOVALE","doc":"1019035775","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"cjimenezdovale@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JUAN ESTEBAN ZAMUDIO FANDIÑO","doc":"1019843638","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"jzamudiofandino@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"NATALY MUÑOZ LOZANO","doc":"1028865085","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"19nat.9295@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DILAN STIVE RAMIREZ VARGAS","doc":"1028941523","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"dilanramirezv2007@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JHOSEP DAVID SOLANO CARDENAS","doc":"1028943162","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"moto.jdsc@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JEFFERSON STIC CORREA LOPEZ","doc":"1030645589","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"jeffersonsticcorrealopez@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"GERSON SAMUEL SANCHEZ GARCIA","doc":"1031653239","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"gersonsamuel080@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"YINA NATALIA BARBOSA","doc":"1031653801","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"yinaasdfd@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JOSE MANUEL CORREA ARROYO","doc":"1031815474","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"correarroyo2008@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DANIEL ALEJANDRO RANGEL GUZMAN","doc":"1031817150","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"alejorangel2008@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ANA GABRIELA HERNANDEZ RAMOS","doc":"1033722144","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"gabyh0541@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"HEIDY DANIELA ROMERO AGUIAR","doc":"1105896575","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"da933522@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"TALIANA MORENO GUZMAN","doc":"1131329048","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"talianamoreno08@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"MARIA JIMENA REYES AGUDELO","doc":"1147485109","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"jimena12112@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ANDRES CABRALES BAENA","doc":"1147485130","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147234","correo":"andrescabrales322@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},

  /* ── GRUPO 3147235 — ADSO B (Tecnólogo) ── */
  {"nombre":"ALEX JHAIR OBANDO ZUÑIGA","doc":"1013597811","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"lobandoalex@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DEYVI JHOAN VALENCIA BRIÑEZ","doc":"1013600232","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"deiviyea@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"PABLO JULIAN BERNAL GARCIA","doc":"1014661053","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"pablojulian0605@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"NICOL ALEJANDRA MORENO RODRIGUEZ","doc":"1019763978","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"namor1901@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"KEVIN STIVEN PINTO AMAYA","doc":"1024484280","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"pintokevin243@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"MIGUEL ANGEL RUBIANO VARGAS","doc":"1032678894","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"miguelangelrubianovargas@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"LAURA SOFIA YEPES ORJUELA","doc":"1034287971","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"yepesorjuelalaurasofia@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"MANUELA ALEJANDRA MARROQUIN BASABE","doc":"1069332082","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"marroquinbasabm75@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"MARIA FERNANDA MORENO ACOSTA","doc":"1140916735","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"mm43651@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"SAMUEL ESTEBAN SANCHEZ MORENO","doc":"1141116538","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"SamaelDValiere@hotmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JOHAN ALEJANDRO QUINTERO BARROS","doc":"1141714400","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"johanqui302006@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JUAN MANUEL CULMA SANTOFIMIO","doc":"1010964038","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"juanculmamanuelsantofimio@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DANNA GISELLE PEREZ GOMEZ","doc":"1012918731","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"dannaguisellep@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"BREYNER SNEYDER ALFONSO","doc":"1014481489","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"balfonso@arp.edu.co","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"MARIANA ESPINOZA ARIAS","doc":"1018432856","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"marianaarias7887@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"LINA MARCELA TORO ORTIZ","doc":"1021675381","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"lmtoroo821@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DANNY ALEJANDRO GONZALEZ YATE","doc":"1023379137","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"dannygonzalezy@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"LUZ STEFANNY HERRERA RODRIGUEZ","doc":"1023893550","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"luzh2298@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"SERGIO STEVEN TIQUE BECERRA","doc":"1025537590","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"sergiotiquebec101@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ANDRES FELIPE INFANTE CORTES","doc":"1027402287","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"pipe.infacor@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"LAURA LIZETH GUTIERREZ CELIS","doc":"1029282306","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"lauralizethgutierrez8@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"CAROL ANDREA RUIZ CASTAÑEDA","doc":"1030565865","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"caritool152007@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"MICHAEL ANDRES VARON VARON","doc":"1031423307","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"michael.varon307@educacionbogota.edu.co","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"BRAINER ESNEIDER MARTINEZ GONZALEZ","doc":"1074415838","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"bg7359375@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DUVER ARLEY GONZALEZ BENAVIDES","doc":"1081405243","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"gonzalesarley507@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"SANTIAGO ANDRES ORDOÑEZ SOLARTE","doc":"1083812753","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"santiagoordonez501@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"IVAN RAMIRO YATE LOZANO","doc":"1118024408","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147235","correo":"ivanfree223@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},

  /* ── GRUPO 3147251 — ADSO C (Tecnólogo) ── */
  {"nombre":"LAURA SOFIA BURITICA CALDERON","doc":"1013117437","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"lauraunisena25@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ANA SOFIA SANCHEZ RIVERA","doc":"1013602421","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"anasanchezrivera62@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"MICHAEL STEVEN PULIDO VILLANUEVA","doc":"1019988200","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"villanuevamai2006@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ANDRES FELIPE GUIO APONTE","doc":"1024495901","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"pipeguio11@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JEHIMY VANESSA HERNANDEZ RODRIGUEZ","doc":"1025533776","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"jehimyhernandez07@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"SANTIAGO ELY HURTADO MEJIA","doc":"1033702510","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"shurtado308@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"SHIRLY YASBLEIDY OSTOS GARZON","doc":"1057014972","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"chirlyostos15@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"BRANDON FELIPE MORALES HERRERA","doc":"1095551619","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"felipemoralesherrera888@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JUAN DIEGO RODRIGUEZ LEON","doc":"1140916997","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"juandisrod2019@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"DANA SOFIA ZARTA BRIÑEZ","doc":"1141915064","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"dannasofiazartabrines@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"PAULA ALEJANDRA BUITRAGO CASALLAS","doc":"1014667317","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"buitragopaula769@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ASHLY MICHELLE GARCIA VASQUEZ","doc":"1014669087","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"ashly3268@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JHON FREDDY PAEZ GARAY","doc":"1022950129","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"paezgarayjhonfreddy@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"CATALINA PEREZ LOSADA","doc":"1023303772","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"catalinalosadap@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"EMILY VANESSA REMICIO TAPIERO","doc":"1023378488","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"vanessatvtapiero@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"CRISTAL SHARIK LEAL GUEVARA","doc":"1025537799","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"clealguevara@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ANGIE JULIETH CORONADO MONTAÑEZ","doc":"1028784209","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"angieyclaudia2314@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JOSE DAVID LEON RUIZ","doc":"1031127976","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"leonruizjosedavid44@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ASHLY DAYANNA RIZO RODRIGUEZ","doc":"1031423086","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"ashlyrizor17@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"ANDRES SANTIAGO SALAS CHAVEZ","doc":"1032431670","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"santosalas2008@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"JERSON JULIAN RIVERA PASACHOA","doc":"1033102762","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"julianzatet@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"KAROL DANIELA ARIAS BOGOTA","doc":"1033712142","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"daniela.bogota27@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"HEIMAR ANDRES AREVALO CELIS","doc":"1051184628","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"heimarcelis27@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"SARA VALENTINA DIAZ ROJAS","doc":"1074813671","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"saravalentinadiazrojas@gmail.com","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"},
  {"nombre":"LAURA VALENTINA GALINDO ORTIZ","doc":"1103501833","programa":"ANALISIS Y DESARROLLO DE SOFTWARE","nivel":"TECNÓLOGO","grupo":"3147251","correo":"laura.galindo@cedlavictoria.edu.co","inicio_ep":"2026-02-10","fin_contrato":null,"sem":"R"}
];

export const RAPS_BASE = {
  "1043967541":{a:46,t:47,p:98},
  "1074415481":{a:46,t:47,p:98},
  "1140914672":{a:46,t:47,p:98},
  "1141515184":{a:46,t:47,p:98},
  "1193230246":{a:46,t:47,p:98},
  "1012370457":{a:46,t:47,p:98},
  "1019991485":{a:46,t:47,p:98},
  "1022355461":{a:46,t:47,p:98},
  "1023374300":{a:46,t:47,p:98},
  "1023378880":{a:46,t:47,p:98},
  "1028663706":{a:46,t:47,p:98},
  "1098072982":{a:46,t:47,p:98},
  "1140915524":{a:46,t:47,p:98}
};

// Completar RAPs para grupos ADSO con datos simulados
export const RAPS_DATA = { ...RAPS_BASE };
APRENDICES_DATA.filter(a => a.grupo !== '3068389').forEach(a => {
  if (!RAPS_DATA[a.doc]) {
    const aprobados = Math.floor(Math.random() * 20 + 50);
    RAPS_DATA[a.doc] = { a: aprobados, t: 75, p: Math.round(aprobados / 75 * 100) };
  }
});
