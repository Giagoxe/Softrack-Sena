// utils/exportExcel.js — Exportación real a .xlsx con múltiples hojas
import * as XLSX from 'xlsx';
import { fmtD, fmtDT, bitCount, segCount } from './helpers';
import { BIT_REQUIRED, SEG_REQUIRED, INSTRUCTOR } from './config';

/**
 * Exporta todos los datos a un archivo Excel con 4 hojas:
 * 1. Resumen general
 * 2. Todos los aprendices
 * 3. Estado Drive (F-147 y F-023)
 * 4. Alertas (sin contrato + vencimientos)
 */
export function exportarExcel(AP, RAPS, driveCache, alertasVenc = []) {
  const wb = XLSX.utils.book_new();

  /* ── Hoja 1: Resumen ── */
  const tot  = AP.length;
  const vig  = AP.filter(a => a.sem === 'G').length;
  const sin  = AP.filter(a => a.sem === 'R').length;
  const ter  = AP.filter(a => a.sem === 'Y').length;
  const bitOk = AP.filter(a => bitCount(driveCache, a.doc) > 0).length;
  const segOk = AP.filter(a => segCount(driveCache, a.doc) > 0).length;
  const hoy  = new Date().toLocaleDateString('es-CO', { year:'numeric', month:'long', day:'numeric' });

  const resumen = [
    ['APRENDITRACK SENA — REPORTE ETAPA PRODUCTIVA'],
    [`Generado: ${hoy}`],
    [`Instructor: ${INSTRUCTOR.nombre} | ${INSTRUCTOR.rol}`],
    [],
    ['RESUMEN GENERAL', '', 'CANTIDAD', '% DEL TOTAL'],
    ['Total aprendices',        '', tot,   '100%'],
    ['Contratos vigentes',      '', vig,   pct(vig, tot)],
    ['Sin contrato',            '', sin,   pct(sin, tot)],
    ['Terminados',              '', ter,   pct(ter, tot)],
    [],
    ['ESTADO DRIVE', '', 'CON ARCHIVOS', '% DEL TOTAL'],
    ['F-147 Bitácoras',         '', bitOk, pct(bitOk, tot)],
    ['F-023 Seguimientos',      '', segOk, pct(segOk, tot)],
    [],
    ['FICHAS DE FORMACIÓN', '', 'APRENDICES', 'VIGENTES'],
    ...['3068389','3147234','3147235','3147251'].map(g => {
      const aps = AP.filter(a => a.grupo === g);
      const v   = aps.filter(a => a.sem === 'G').length;
      return [`Ficha ${g}`, '', aps.length, v];
    }),
  ];
  const ws1 = XLSX.utils.aoa_to_sheet(resumen);
  ws1['!cols'] = [{ wch: 30 }, { wch: 5 }, { wch: 15 }, { wch: 15 }];
  XLSX.utils.book_append_sheet(wb, ws1, 'Resumen');

  /* ── Hoja 2: Aprendices ── */
  const aprRows = [
    ['#', 'Nombre', 'Documento', 'Nivel', 'Grupo', 'Programa', 'Correo', 'Inicio EP', 'Fin Contrato', 'Estado', 'RAPs Aprobados', 'RAPs Total', 'RAPs %'],
    ...AP.map((a, i) => {
      const r = RAPS[a.doc] || { a: 0, t: 1, p: 0 };
      return [
        i + 1, a.nombre, a.doc, a.nivel, a.grupo, a.programa,
        a.correo, fmtD(a.inicio_ep), a.fin_contrato ? fmtD(a.fin_contrato) : 'Sin contrato',
        a.sem === 'G' ? 'Vigente' : a.sem === 'Y' ? 'Terminado' : 'Sin contrato',
        r.a, r.t, r.p + '%'
      ];
    })
  ];
  const ws2 = XLSX.utils.aoa_to_sheet(aprRows);
  ws2['!cols'] = [4, 35, 14, 12, 10, 30, 30, 12, 14, 14, 14, 12, 10].map(w => ({ wch: w }));
  XLSX.utils.book_append_sheet(wb, ws2, 'Aprendices');

  /* ── Hoja 3: Estado Drive ── */
  const driveRows = [
    ['#', 'Nombre', 'Documento', 'Grupo', 'Carpeta en Drive', 'F-147 Archivos', 'F-147 Último', 'F-023 Archivos', 'F-023 Último', 'Estado Bitácora', 'Estado Seguimiento'],
    ...AP.map((a, i) => {
      const c   = driveCache[a.doc];
      const bd  = c?.bit;
      const sd  = c?.seg;
      const bc  = bd?.count ?? -1;
      const sc  = sd?.count ?? -1;
      return [
        i + 1, a.nombre, a.doc, a.grupo,
        c?.aprFolderName || (c?.notFound ? 'No encontrado' : '—'),
        bc === -1 ? '—' : bc,
        bd?.last ? fmtDT(bd.last) : '—',
        sc === -1 ? '—' : sc,
        sd?.last ? fmtDT(sd.last) : '—',
        bc > 0 ? 'Con archivos ✓' : bc === 0 ? 'Sin archivos' : 'No encontrado',
        sc > 0 ? 'Con archivos ✓' : sc === 0 ? 'Sin archivos' : 'No encontrado',
      ];
    })
  ];
  const ws3 = XLSX.utils.aoa_to_sheet(driveRows);
  ws3['!cols'] = [4, 35, 14, 10, 25, 16, 18, 16, 18, 18, 20].map(w => ({ wch: w }));
  XLSX.utils.book_append_sheet(wb, ws3, 'Estado Drive');

  /* ── Hoja 4: Alertas ── */
  const sinCont = AP.filter(a => a.sem === 'R');
  const alertRows = [
    ['ALERTAS — Sin contrato'],
    ['#', 'Nombre', 'Documento', 'Grupo', 'Nivel', 'Inicio EP'],
    ...sinCont.map((a, i) => [i+1, a.nombre, a.doc, a.grupo, a.nivel, fmtD(a.inicio_ep)]),
    [],
    ['ALERTAS — Vencimientos próximos'],
    ['#', 'Nombre', 'Documento', 'Grupo', 'Fin Contrato', 'Días restantes', 'Estado'],
    ...alertasVenc.map((a, i) => [
      i+1, a.nombre, a.doc, a.grupo,
      fmtD(a.fin_contrato),
      a._alerta === 'vencido' ? `Venció hace ${a._dias} días` : `${a._dias} días`,
      a._alerta === 'vencido' ? 'VENCIDO' : a._alerta === 'critico' ? 'CRÍTICO (<30 días)' : 'PRÓXIMO (<60 días)'
    ]),
  ];
  const ws4 = XLSX.utils.aoa_to_sheet(alertRows);
  ws4['!cols'] = [4, 35, 14, 10, 12, 20, 22].map(w => ({ wch: w }));
  XLSX.utils.book_append_sheet(wb, ws4, 'Alertas');

  /* ── Descargar ── */
  const fecha = new Date().toISOString().substring(0, 10);
  XLSX.writeFile(wb, `AprendiTrack_${fecha}.xlsx`);
}

const pct = (v, t) => t > 0 ? Math.round(v / t * 100) + '%' : '0%';
