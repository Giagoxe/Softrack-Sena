// components/Sidebar.jsx
import { useStore } from '../store';
import { INSTRUCTOR } from '../utils/config';

const NAV_ITEMS = [
  { id: 'dash',         label: 'Dashboard',          section: 'Principal', icon: DashIcon },
  { id: 'aprendices',   label: 'Aprendices',          section: null,        icon: UsersIcon,   badge: 'ap' },
  { id: 'grupos',       label: 'Grupos / Fichas',     section: null,        icon: GroupIcon },
  { id: 'bitacoras',    label: 'F-147 Bitácoras',     section: 'Drive',     icon: FileIcon,    badge: 'bit' },
  { id: 'seguimientos', label: 'F-023 Seguimientos',  section: null,        icon: CheckIcon,   badge: 'seg' },
  { id: 'alertas',      label: 'Alertas',             section: 'Gestión',   icon: BellIcon,    badge: 'alr' },
  { id: 'raps',         label: 'RAPs / Avance',       section: null,        icon: ActivityIcon },
  { id: 'exportar',     label: 'Exportar',            section: null,        icon: DownloadIcon },
];

export default function Sidebar() {
  const { currentPage, navTo, AP, driveConnected, driveCache, scanInProgress,
          connectDrive, disconnectDrive, syncDrive, lastSync } = useStore();

  const sin  = AP.filter(a => a.sem === 'R').length;
  const badges = { ap: AP.length, alr: sin, bit: '—', seg: '—' };

  return (
    <nav className="sb">
      <div className="strip" />

      {/* Logo */}
      <div className="sb-logo">
        <div className="logo-ic">
          <svg viewBox="0 0 40 40" fill="none" width="24" height="24">
            <circle cx="20" cy="20" r="18" fill="#009e3f"/>
            <path d="M12 24c0-4.4 3.6-8 8-8s8 3.6 8 8" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
            <circle cx="20" cy="14" r="3" fill="white"/>
            <path d="M14 28h12" stroke="white" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>
        <div>
          <div className="logo-t">AprendiTrack</div>
          <div className="logo-s">SENA · Colombia</div>
        </div>
      </div>

      {/* Nav */}
      <div className="nav">
        {NAV_ITEMS.map((item, i) => {
          const prevSection = i > 0 ? NAV_ITEMS[i - 1].section : null;
          const showSection = item.section && item.section !== prevSection;
          return (
            <div key={item.id}>
              {showSection && <div className="nsec">{item.section}</div>}
              <div
                className={`ni ${currentPage === item.id ? 'active' : ''}`}
                onClick={() => navTo(item.id)}
              >
                <item.icon />
                <span className="ni-label">{item.label}</span>
                {item.badge && badges[item.badge] !== undefined && (
                  <span className={`nb ${item.badge === 'alr' ? 'nb-r' : 'nb-g'}`}>
                    {badges[item.badge]}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Panel Drive */}
      <div className={`drive-status ${driveConnected ? 'ds-connected' : 'ds-disconnected'}`}>
        <div className="ds-row">
          <div className={`ds-dot ${driveConnected ? 'on' : 'off'}`} />
          <span className="ds-lbl">{driveConnected ? 'Drive conectado' : 'Drive no conectado'}</span>
        </div>
        <div className="ds-info">
          {driveConnected
            ? lastSync ? `Sync: ${lastSync.toLocaleTimeString('es-CO')}` : 'Escaneando…'
            : 'Conecta para leer archivos reales'}
        </div>
        <button
          className={`ds-btn ${driveConnected ? 'ds-btn-disc' : 'ds-btn-conn'}`}
          onClick={driveConnected ? disconnectDrive : connectDrive}
        >
          {driveConnected ? 'Desconectar Drive' : 'Conectar con Google Drive'}
        </button>
      </div>

      {/* Footer usuario */}
      <div className="sb-footer">
        <div className="urow">
          <div className="uav">{INSTRUCTOR.iniciales}</div>
          <div>
            <div className="uname">{INSTRUCTOR.nombre}</div>
            <div className="urole">{INSTRUCTOR.rol}</div>
          </div>
        </div>
      </div>
    </nav>
  );
}

/* ── Íconos SVG inline ── */
function DashIcon()     { return <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg> }
function UsersIcon()    { return <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="9" cy="7" r="4"/><path d="M2 20v-1a7 7 0 0114 0v1"/><circle cx="19" cy="11" r="3"/><path d="M22 20v-.5a4.5 4.5 0 00-4.5-4.5"/></svg> }
function GroupIcon()    { return <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg> }
function FileIcon()     { return <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg> }
function CheckIcon()    { return <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg> }
function BellIcon()     { return <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg> }
function ActivityIcon() { return <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg> }
function DownloadIcon() { return <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> }
