// components/Modals.jsx — Todos los modales de la app
import { useState } from 'react';
import { useStore } from '../store';
import { StatusBadge, DriveFolderStatus } from './UI';
import { initials, colFor, fmtDT, fmtD } from '../utils/helpers';
import { PROG_MAP } from '../utils/config';

/* ── Modal Detalle Aprendiz ── */
export function ModalDetalle() {
  const { AP, RAPS, driveCache, driveConnected, modals, closeDetail, openEditar } = useStore();
  const doc = modals.detail;
  if (!doc) return null;

  const a = AP.find(x => x.doc === doc);
  if (!a) return null;
  const r = RAPS[a.doc] || { a: 0, t: 1, p: 0 };

  return (
    <div className="ov" onClick={e => e.target === e.currentTarget && closeDetail()}>
      <div className="modal" style={{ width: 560 }}>
        <div className="det-hd">
          <div className="det-av" style={{ background: colFor(a.nombre) }}>
            {initials(a.nombre)}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--head)', fontSize: 17, fontWeight: 700, color: '#fff' }}>{a.nombre}</div>
            <div style={{ fontSize: 11.5, color: 'rgba(255,255,255,.7)', marginTop: 3 }}>
              {a.programa} · {a.nivel} · Ficha {a.grupo}
            </div>
          </div>
          <div className="mx" onClick={closeDetail} style={{ background: 'rgba(255,255,255,.2)', borderColor: 'rgba(255,255,255,.3)', color: '#fff' }}>×</div>
        </div>
        <div className="mb">
          <div className="det-grid">
            {[
              { l: 'Documento',       v: a.doc },
              { l: 'Estado contrato', v: <StatusBadge sem={a.sem} /> },
              { l: 'Inicio E.P.',     v: fmtDT(a.inicio_ep) },
              { l: 'Fin contrato',    v: a.fin_contrato ? fmtDT(a.fin_contrato) : '— Sin contrato' },
              { l: 'RAPs aprobados',  v: `${r.a}/${r.t} (${r.p}%)` },
              { l: 'Correo',          v: a.correo || '—' },
            ].map(({ l, v }) => (
              <div key={l} className="det-box">
                <div className="det-lbl">{l}</div>
                <div className="det-val">{v}</div>
              </div>
            ))}
          </div>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--sena2)', textTransform: 'uppercase', letterSpacing: .5, marginBottom: 8 }}>
            Estado en Google Drive
          </div>
          <DriveFolderStatus cache={driveCache} doc={doc} />
          <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap' }}>
            {a.correo && (
              <a href={`mailto:${a.correo}`} className="btn btn-ghost btn-sm">📧 Correo</a>
            )}
            <button className="btn btn-ghost btn-sm" onClick={() => { closeDetail(); openEditar(AP.indexOf(a)); }}>
              ✏ Editar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Modal Nuevo Aprendiz ── */
export function ModalNuevo() {
  const { modals, closeNuevo, agregarAprendiz } = useStore();
  const [form, setForm] = useState({ nom: '', ape: '', doc: '', nivel: 'TÉCNICO', grupo: '3068389', correo: '', ep: '', fin: '', est: 'R' });

  if (!modals.nuevo) return null;

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const guardar = () => {
    if (!form.nom || !form.ape || !form.doc) return;
    const ok = agregarAprendiz({
      nombre:       (form.nom + ' ' + form.ape).toUpperCase(),
      doc:          form.doc,
      programa:     PROG_MAP[form.grupo] || '',
      nivel:        form.nivel,
      grupo:        form.grupo,
      correo:       form.correo,
      inicio_ep:    form.ep,
      fin_contrato: form.fin || null,
      sem:          form.est,
    });
    if (ok) { closeNuevo(); setForm({ nom:'',ape:'',doc:'',nivel:'TÉCNICO',grupo:'3068389',correo:'',ep:'',fin:'',est:'R' }); }
  };

  return (
    <div className="ov" onClick={e => e.target === e.currentTarget && closeNuevo()}>
      <div className="modal">
        <div className="mh"><div className="mt">Registrar nuevo aprendiz</div><div className="mx" onClick={closeNuevo}>×</div></div>
        <div className="mb">
          <div className="frow">
            <div className="fg"><label className="fl">Nombres *</label><input className="fi" value={form.nom} onChange={e=>set('nom',e.target.value)} placeholder="Nombres" /></div>
            <div className="fg"><label className="fl">Apellidos *</label><input className="fi" value={form.ape} onChange={e=>set('ape',e.target.value)} placeholder="Apellidos" /></div>
          </div>
          <div className="frow">
            <div className="fg"><label className="fl">Documento *</label><input className="fi" value={form.doc} onChange={e=>set('doc',e.target.value)} placeholder="N° documento" /></div>
            <div className="fg"><label className="fl">Nivel *</label>
              <select className="fi" value={form.nivel} onChange={e=>set('nivel',e.target.value)}>
                <option value="TÉCNICO">TÉCNICO</option><option value="TECNÓLOGO">TECNÓLOGO</option>
              </select>
            </div>
          </div>
          <div className="frow">
            <div className="fg"><label className="fl">Grupo *</label>
              <select className="fi" value={form.grupo} onChange={e=>set('grupo',e.target.value)}>
                {Object.entries(PROG_MAP).map(([k,v])=><option key={k} value={k}>{k} — {v}</option>)}
              </select>
            </div>
            <div className="fg"><label className="fl">Estado contrato</label>
              <select className="fi" value={form.est} onChange={e=>set('est',e.target.value)}>
                <option value="G">Vigente</option><option value="Y">Terminado</option><option value="R">Sin contrato</option>
              </select>
            </div>
          </div>
          <div className="fg"><label className="fl">Correo</label><input className="fi" type="email" value={form.correo} onChange={e=>set('correo',e.target.value)} placeholder="correo@gmail.com" /></div>
          <div className="frow">
            <div className="fg"><label className="fl">Inicio EP</label><input className="fi" type="date" value={form.ep} onChange={e=>set('ep',e.target.value)} /></div>
            <div className="fg"><label className="fl">Fin contrato</label><input className="fi" type="date" value={form.fin} onChange={e=>set('fin',e.target.value)} /></div>
          </div>
        </div>
        <div className="mf">
          <button className="btn btn-ghost" onClick={closeNuevo}>Cancelar</button>
          <button className="btn btn-sena" onClick={guardar}>✓ Registrar</button>
        </div>
      </div>
    </div>
  );
}

/* ── Modal Editar Aprendiz ── */
export function ModalEditar() {
  const { AP, modals, closeEditar, editarAprendiz } = useStore();
  const idx = modals.editar;
  if (idx === null || idx === undefined) return null;
  const a = AP[idx];
  const [form, setForm] = useState({ nombre: a.nombre, doc: a.doc, correo: a.correo||'', ep: a.inicio_ep||'', fin: a.fin_contrato||'', est: a.sem });
  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const guardar = () => {
    editarAprendiz(idx, { nombre:form.nombre.toUpperCase(), doc:form.doc, correo:form.correo, inicio_ep:form.ep, fin_contrato:form.fin||null, sem:form.est });
    closeEditar();
  };

  return (
    <div className="ov" onClick={e => e.target === e.currentTarget && closeEditar()}>
      <div className="modal">
        <div className="mh"><div className="mt">Editar aprendiz</div><div className="mx" onClick={closeEditar}>×</div></div>
        <div className="mb">
          <div className="fg"><label className="fl">Nombre completo</label><input className="fi" value={form.nombre} onChange={e=>set('nombre',e.target.value)} /></div>
          <div className="frow">
            <div className="fg"><label className="fl">Documento</label><input className="fi" value={form.doc} onChange={e=>set('doc',e.target.value)} /></div>
            <div className="fg"><label className="fl">Correo</label><input className="fi" type="email" value={form.correo} onChange={e=>set('correo',e.target.value)} /></div>
          </div>
          <div className="frow">
            <div className="fg"><label className="fl">Inicio EP</label><input className="fi" type="date" value={form.ep} onChange={e=>set('ep',e.target.value)} /></div>
            <div className="fg"><label className="fl">Fin contrato</label><input className="fi" type="date" value={form.fin} onChange={e=>set('fin',e.target.value)} /></div>
          </div>
          <div className="fg"><label className="fl">Estado contrato</label>
            <select className="fi" value={form.est} onChange={e=>set('est',e.target.value)}>
              <option value="G">Vigente</option><option value="Y">Terminado</option><option value="R">Sin contrato</option>
            </select>
          </div>
        </div>
        <div className="mf">
          <button className="btn btn-ghost" onClick={closeEditar}>Cancelar</button>
          <button className="btn btn-sena" onClick={guardar}>✓ Guardar</button>
        </div>
      </div>
    </div>
  );
}
