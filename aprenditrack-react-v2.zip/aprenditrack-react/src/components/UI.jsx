// components/UI.jsx — Componentes reutilizables pequeños
import { initials, colFor, fmtDT, bitCount, segCount } from '../utils/helpers';
import { BIT_REQUIRED, SEG_REQUIRED } from '../utils/config';

/** Badge de estado de contrato */
export function StatusBadge({ sem }) {
  const map = { G: ['st-G', 'Vigente'], Y: ['st-Y', 'Terminado'], R: ['st-R', 'Sin contrato'] };
  const [cls, label] = map[sem] || ['st-R', 'Sin contrato'];
  return <span className={`st ${cls}`}><span className="std" />{label}</span>;
}

/** Pill de nivel formación */
export function NivelPill({ nivel }) {
  return nivel === 'TÉCNICO'
    ? <span className="pill p-tec">Técnico</span>
    : <span className="pill p-tecl">Tecnólogo</span>;
}

/** Barra de progreso con porcentaje */
export function ProgBar({ pct, sem }) {
  const colors = { G: 'var(--gn)', Y: 'var(--yl)', R: 'var(--rd)' };
  const color  = colors[sem] || 'var(--t4)';
  return (
    <div className="prog-wrap">
      <div className="prog">
        <div className="pf" style={{ width: `${pct}%`, background: color }} />
      </div>
      <span className="prog-pct" style={{ color }}>{pct}%</span>
    </div>
  );
}

/** Barra de progreso grande con label */
export function ProgLg({ label, val, total, color, sub }) {
  const pct = total > 0 ? Math.round(val / total * 100) : 0;
  return (
    <div style={{ marginBottom: 10 }}>
      <div className="prog-label">
        <span className="prog-name">
          {label}{sub && <span style={{ color: 'var(--t3)', fontWeight: 400 }}> {sub}</span>}
        </span>
        <span className="prog-val" style={{ color }}>
          {val} / {total} <span style={{ fontSize: 10, color: 'var(--t3)' }}>({pct}%)</span>
        </span>
      </div>
      <div className="prog-lg">
        <div className="pf" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

/** Avatar mini con iniciales y color */
export function MiniAvatar({ nombre }) {
  return (
    <div className="mav" style={{ background: colFor(nombre), color: '#fff' }}>
      {initials(nombre)}
    </div>
  );
}

/** Celda de nombre con avatar */
export function NameCell({ nombre, sub }) {
  return (
    <div className="pcell">
      <MiniAvatar nombre={nombre} />
      <div>
        <div className="pname">{nombre}</div>
        {sub && <div className="psub">{sub}</div>}
      </div>
    </div>
  );
}

/** Contador de archivos Drive */
export function FCount({ count, required }) {
  if (count === -1) return <span className="fcount fc-na">—</span>;
  if (count >= required) return <span className="fcount fc-ok">{count}/{required} ✓</span>;
  if (count > 0)  return <span className="fcount fc-pend">{count}/{required}</span>;
  return <span className="fcount fc-miss">0/{required}</span>;
}

/** Métrica KPI card */
export function MetricCard({ tipo, label, value, sub, pct, color, icon, onClick }) {
  return (
    <div className={`mc mc-${tipo}`} onClick={onClick} style={{ cursor: onClick ? 'pointer' : 'default' }}>
      {icon && <div className="mc-icon">{icon}</div>}
      <div className="ml">{label}</div>
      <div className="mv" style={{ color }}>{value}</div>
      <div className="ms">{sub}</div>
      {pct !== undefined && (
        <div className="mc-bar">
          <div className="mc-bar-track">
            <div className="mc-bar-fill" style={{ width: `${pct}%`, background: color }} />
          </div>
        </div>
      )}
    </div>
  );
}

/** Pantalla de "conecta Drive" */
export function ConnectScreen({ onConnect }) {
  return (
    <div className="connect-screen">
      <div className="cs-ico">
        <svg width="40" height="40" fill="none" stroke="var(--sena)" strokeWidth="1.5" viewBox="0 0 24 24">
          <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>
        </svg>
      </div>
      <div className="cs-title">Conecta Google Drive primero</div>
      <div className="cs-sub">
        Haz clic en "Conectar con Google Drive" en el panel izquierdo y selecciona
        la carpeta <strong>SEGUIMIENTO ETAPA PRODUCTIVA</strong> en tu unidad H:\.
      </div>
      <button className="btn btn-sena" onClick={onConnect}>Conectar con Drive</button>
    </div>
  );
}

/** Drive folder status dentro del modal detalle */
export function DriveFolderStatus({ cache, doc }) {
  const entry = cache[doc];
  if (!entry) return <div style={{ fontSize: 12, color: 'var(--t3)', padding: 8 }}>Ejecuta "Actualizar Drive" para ver datos</div>;
  if (entry.notFound) return <div style={{ fontSize: 12, color: 'var(--rd)', padding: 8 }}>⚠ Carpeta no encontrada en Drive</div>;

  const { bit, seg, aprFolderName } = entry;
  return (
    <div className="folder-status">
      <div className="folder-row">
        <div className="folder-name">📁 {aprFolderName || 'Carpeta aprendiz'}</div>
      </div>
      <div className="folder-row">
        <div className="folder-name">📄 F-147 BITÁCORAS</div>
        <FCount count={bit?.count ?? -1} required={BIT_REQUIRED} />
      </div>
      <div className="folder-row">
        <div className="folder-name">✅ F-023 SEGUIMIENTOS</div>
        <FCount count={seg?.count ?? -1} required={SEG_REQUIRED} />
      </div>
      {bit?.last && (
        <div style={{ fontSize: 10.5, color: 'var(--t3)', marginTop: 6 }}>
          Último archivo: {fmtDT(bit.last)}
        </div>
      )}
    </div>
  );
}
